package com.example.pcControl;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.pcControl.data.GeneralData;
import com.example.pcControl.network.HeartBeats;
import com.example.pcControl.network.SocketListener;
import com.example.pcControl.network.SocketSender;
import com.example.pcControl.tools.LoadData;

public class MainActivity extends AppCompatActivity {
    public static volatile MainActivity instance;
    private boolean alreadyConnected = false;
    //private Thread listenerThread = null;
    private boolean firstLaunch = true;
    //private Handler handler = null;
    //private boolean wrongPassword;

    public static MainActivity getInstance(){
        if(instance == null){
            instance = new MainActivity();
        }
        return instance;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if(firstLaunch){
            loadOnLaunchData();
        }

        Button setSettingsBtn = (Button) findViewById(R.id.settings_btn);
        setSettingsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent startIntent = new Intent(getApplicationContext(), SettingsActivity.class);
//                setContentView(R.layout.settings_view);
                startActivity(startIntent);
            }
        });

        Button connectBtn = (Button) findViewById(R.id.connect_btn);
        connectBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                connect();
            }
        });



//        Button backSettingsBtn = (Button) findViewById(R.id.back_settings_btn);
//        backSettingsBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                setContentView(R.layout.activity_main);
//            }
//        });
    }

    public void connect(){
        if(GeneralData.ip!=null && GeneralData.port!=null && GeneralData.password!=null &&
                !GeneralData.ip.equals("") && !GeneralData.port.equals("") && !GeneralData.password.equals("")) {
            if (!alreadyConnected) {
                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);
                GeneralData.socketSender = new SocketSender();
                GeneralData.socketSender.startConnection(GeneralData.ip, Integer.valueOf(GeneralData.port));
                if(!GeneralData.socketSender.initialized)
                {
                    System.out.println("Socket sender IS NOT initialized! (MainActivity)");
                    return;
                }
            }
            SocketSender sender = GeneralData.socketSender;
            //sender.startConnection("IP", Integer.valueOf("12345"));                                    //localhost to ip
            //SocketListener listener = SocketListener.getInstance();
            if (!alreadyConnected) {
                GeneralData.socketListener = new Thread(SocketListener.getInstance());
                GeneralData.socketListener.start();

            }
            //sender.sendMessage("android is connecting", false);
            sender.sendMessage("$auth.request.password=" + GeneralData.password, false);
            //sender.sendMessage("ugfasdfg", false);
            alreadyConnected = true;
            GeneralData.wrongPassword = false;

            if (GeneralData.handler == null) {
                GeneralData.handler = new Handler();
            }
            GeneralData.handler.postDelayed(loopConnectionWait, 20);
        }
        else{
            Toast.makeText(getApplicationContext(), "Not enough data to connect", Toast.LENGTH_SHORT);
            alreadyConnected = false;
        }
    }

    public void loadOnLaunchData(){
        GeneralData.ip = LoadData.loadString(getSharedPreferences(GeneralData.sharedPrefs, MODE_PRIVATE), "settings_main_ip");
        GeneralData.port = LoadData.loadString(getSharedPreferences(GeneralData.sharedPrefs, MODE_PRIVATE), "settings_main_port");
        GeneralData.password = LoadData.loadString(getSharedPreferences(GeneralData.sharedPrefs, MODE_PRIVATE), "settings_main_password");
        firstLaunch = false;
    }

    private Runnable loopConnectionWait = new Runnable(){
        @Override
        public void run() {
//            System.out.println(wrongPassword);
//            System.out.println(GeneralData.connected);
            if(GeneralData.wrongPassword) return;
            System.out.println(6);
            if(GeneralData.connected) {
                GeneralData.handler.postDelayed(checkPwdGoToConsoleScreen, 200);
            }
            if(!GeneralData.connected){
                GeneralData.handler.postDelayed(loopConnectionWait, 500);
            }
        }
    };

    private Runnable checkPwdGoToConsoleScreen = new Runnable() {
        @Override
        public void run() {
            if (GeneralData.authAccepted == 1) {
                Intent startIntent = new Intent(getApplicationContext(), ConsoleActivity.class);
//                setContentView(R.layout.settings_view);
                startActivity(startIntent);
                GeneralData.connected = true;
                GeneralData.wrongPassword = false;
                System.out.println("4 (from main activity)");
                System.out.println(GeneralData.socketSender + "");
                GeneralData.socketSender.sendMessage("$system.files.getlocation.request");
                GeneralData.socketSender.sendMessage("$system.files.getpathseparator.request");
                GeneralData.reloadFoldersFilesList();
                GeneralData.handler.postDelayed(HeartBeats.loop, 20000);
            } else if (GeneralData.authAccepted == 0) {
                System.out.println(5);
                Toast.makeText(getApplicationContext(), "Wrong password", Toast.LENGTH_SHORT);
                alreadyConnected = false;
                GeneralData.connected = false;
                GeneralData.wrongPassword = true;
            } else {
                Toast.makeText(getApplicationContext(), "General error", Toast.LENGTH_SHORT);
                alreadyConnected = false;
                GeneralData.connected = false;
            }
        }
    };
}