package com.example.pcControl.network;

import java.io.IOException;
import java.net.SocketException;

import com.example.pcControl.data.GeneralData;

public class SocketListener implements Runnable {


    private static volatile SocketListener INSTANCE;

    public static SocketListener getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new SocketListener();
        }
        return INSTANCE;
    }


    @Override
    public void run() {
        try {
            String inputLine = "";
            String displayLine = "";
            while (inputLine != null) {
                SocketSender sender = GeneralData.socketSender;
                //System.out.println("in = " + GeneralData.inSocket);
                try {
                    inputLine = GeneralData.inSocket.readLine();
                }
                catch (SocketException e){
                    onDisconnect();
                    break;
                }
                catch (IOException e){
                    onDisconnect();
                    break;
                }
                catch (NullPointerException e){
                    onDisconnect();
                    break;
                }
                finally {
                    GeneralData.connected = true;
                    displayLine = inputLine;
                }
                if(inputLine != null){
//					if (inputLine.equalsIgnoreCase("servermanager stop serversocket")) {
//						References.getInstance().outSocket.println("Socket Closed");
//						break;
//					}
//					References.outSocket.println("message back to PX");                                                //useful
                    System.out.println("Android got: " + inputLine + "\n");
                    if(inputLine.startsWith("$")) {
                        String[] args = inputLine.substring(1).split("\\.");
                        int len = args.length;
                        if(len>0) {
//                            System.out.println(args[0]);
                            if(args[0].equals("auth")) {
                                if(len>1) {
                                    if(args[1].equals("result")) {
                                        if(len>2) {
                                            if(args[2].equals("accepted")) {
                                                GeneralData.authAccepted = 1;
                                                displayLine = "Connected successfully";
                                                //displayLine = null;
                                            }
                                            else if(args[2].equals("denied")) {
                                                GeneralData.authAccepted = 0;
                                                displayLine = "Unable to connect: wrong password";
                                            }
                                        }
                                    }
                                    if(args[1].equals("alreadyConnected")) {
                                        displayLine = null;
                                    }
                                }
                            }
                            else if(args[0].equals("rscmessage")) {
                                displayLine = "Message from the PC: " + inputLine.substring(12);
                            }
                            else if(args[0].equals("rsccommand")) {
                                if(len>1){
                                    if(args[1].equals("unknown")) {
                                        displayLine = "Unknown command!";
                                    }
                                }
                            }
                            else if(args[0].equals("system")) {
                                if(len>1){
                                    if(args[1].equals("getinfo")) {
                                        if(len>2){
                                            if(args[2].equals("tasklist")) {
                                                if(len>3){
                                                    if(args[3].equals("result")) {
                                                        if(len>4){
                                                            if(args[4].startsWith("text=")){
                                                                String result = "The list of currently running processes:\n" + inputLine.substring(37);
                                                                displayLine = result; //result.replaceAll("&l&ine&", "\n");
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    if(args[1].equals("management")) {
                                        if(len>2){
                                            if(args[2].equals("shutdown")) {
                                                if(len>3){
                                                    if(args[3].equals("usual")) {
                                                        if(len>4){
                                                            if(args[4].equals("accepted")) {
                                                                displayLine = "Shutting down the computer..."; //result.replaceAll("&l&ine&", "\n");
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if(args[1].equals("files")) {
                                        if(len>2) {
                                            if(args[2].equals("getpathseparator")) {
                                                if(len>3) {
                                                    if (args[3].equals("result")) {
                                                        GeneralData.systemSeparator = inputLine.substring(52);
                                                        displayLine = "";
                                                    }
                                                }
                                            }
                                            if(args[2].equals("getlocation")) {
                                                if(len>3) {
                                                    if(args[3].equals("result")) {
                                                        if(len>4) {
                                                            if(args[4].startsWith("location=")) {
                                                                String text = inputLine.substring(42);
                                                                System.out.println("Got the location: " + text);
                                                                GeneralData.currentFolder = text;
                                                                displayLine = "";
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            else if(args[2].equals("fileslist")) {
                                                if(len>3) {
                                                    if(args[3].equals("result") || args[3].equals("silentresult")) {
                                                        if(len>4){
                                                            if(inputLine.length()>42){
                                                                String text = inputLine.substring(42);
                                                                System.out.println("Got files list...");
                                                                String[] files = text.split("&&nex&t&");
                                                                GeneralData.filesList = files;
                                                                if(args[3].equals("result")){
                                                                    displayLine = "The files list:" + "\n";
                                                                    for (int i = 0; i < files.length; i++){
                                                                        displayLine += files[i];
                                                                        if(i<files.length-1){
                                                                            displayLine += "&l&ine&";
                                                                        }
                                                                    }
                                                                    //displayLine += " ";
                                                                }
                                                                else{
                                                                    displayLine = "";
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            else if(args[2].equals("folderslist")) {
                                                if(len>3) {
                                                    if(args[3].equals("result") || args[3].equals("silentresult")) {
                                                        if(len>4){
                                                            if(inputLine.length()>42){
                                                                String text = inputLine.substring(38);
                                                                System.out.println("Got folders list...");
                                                                String[] folders = text.split("&&nex&t&");
                                                                GeneralData.foldersList = folders;
                                                                if(args[3].equals("result")){
                                                                    displayLine = "The folders list:" + "\n";
                                                                    for (int i = 0; i < folders.length; i++){
                                                                        displayLine += folders[i];
                                                                        if(i<folders.length-1){
                                                                            displayLine += "&l&ine&";
                                                                        }
                                                                    }
                                                                    //displayLine += " ";
                                                                }
                                                                else{
                                                                    displayLine = "";
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            else if(args[2].equals("nonfolderslist")) {
                                                if(len>3) {
                                                    if(args[3].equals("result") || args[3].equals("silentresult")) {
                                                        if(len>4){
                                                            if(inputLine.length()>42){
                                                                String text = inputLine.substring(42);
                                                                System.out.println("Got non-folders list...");
                                                                String[] files = text.split("&&nex&t&");
                                                                GeneralData.nonFoldersList = files;
                                                                if(args[3].equals("result")){
                                                                    displayLine = "The non-folders list:" + "&l&ine&";
                                                                    for (int i = 0; i < files.length; i++){
                                                                        displayLine += files[i];
                                                                        if(i<files.length-1){
                                                                            displayLine += "&l&ine&";
                                                                        }
                                                                    }
                                                                    //displayLine += " ";
                                                                }
                                                                else{
                                                                    displayLine = "";
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            else if(args[2].equals("changelocation")) {
                                                if(len>3) {
                                                    if(args[3].equals("result")){
                                                        if(len>4) {
                                                            if (args[4].equals("accepted")) {
                                                                displayLine = "";
                                                                if(len>5) {
                                                                    if (args[5].startsWith("folder=")) {
                                                                        String folder = inputLine.substring(52);
                                                                        GeneralData.lastConsoleOutput += "Entered folder \"" + folder + "\"\n\n"; //"Entered folder \"" + folder + "\"";
                                                                    }
                                                                }
                                                            }
                                                            if (args[4].equals("denied")) {
                                                                if (len > 5) {
                                                                    if (args[5].startsWith("old=")) {
                                                                        GeneralData.currentFolder = inputLine.substring(47);
                                                                        displayLine = "Such fodler doesn't exist.&l&ine&";
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                                }
                                            }
                                    }
                                }
                            }
                        }
                        else {
                            sender.sendMessage("$rcsmessage.error.general");
                        }
                    }

//                    String already = GeneralData.lastConsoleOutput;
//                    String[] rows = already.split("\n");
//                    String newStr = "";
//                    if(rows.length > 40){
//                        for (int i = rows.length-40; i<rows.length; i++){
//                            newStr += rows[i];
//                        }
//                        newStr += inputLine + "\n";
//                    }

                    if (displayLine != null) {
                        if (GeneralData.authAccepted == 1) {
                            if(!displayLine.equals("")){
                                displayLine += "&l&ine& ";
                            }
                            if(displayLine.contains("&l&ine&")){
                                String[] list = displayLine.split("&l&ine&");
                                for (int i = 0; i < list.length; i++){
                                    GeneralData.lastConsoleOutput += list[i] + "\n";
                                    //System.out.println("added output, current: " + GeneralData.lastConsoleOutput);
                                    //Thread.sleep(0);
                                }
                            }
                            else {
                                if(!displayLine.equals("")) {
                                    GeneralData.lastConsoleOutput += displayLine + "\n";
                                }
                            }
                        }
                    }
                }
//				if(References.getInstance().clientSocket.isClosed()) {
//					System.out.println("closed");
//				}
            }

            GeneralData.socket.close();

            if(GeneralData.authAccepted==1 && GeneralData.disconnected==false) {
                System.out.println(3);
                onDisconnect();
            }
            //System.out.println(GeneralData.authAccepted);
            if(GeneralData.authAccepted==1) {
                GeneralData.lastConsoleOutput += "Connection lost, reconnecting...\n";
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void onDisconnect() {
        GeneralData.disconnected = true;
        GeneralData.connected = false;
        GeneralData.socketListener = null;
        GeneralData.socketReconnecter = new Thread(ConnectionChecker.getInstance());
        GeneralData.socketReconnecter.start();
    }
}