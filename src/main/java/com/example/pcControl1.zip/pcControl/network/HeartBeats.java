package com.example.pcControl.network;

import com.example.pcControl.data.GeneralData;

public class HeartBeats {

    public static Runnable loop = new Runnable() {
        @Override
        public void run() {
            System.out.println("1 (GeneralData.connected): " + GeneralData.connected);
            System.out.println("2 (GeneralData.socketSender!=null):" + GeneralData.socketSender!=null);
            System.out.println("3 (GeneralData.socketSender.initialized):" + (GeneralData.socketSender.initialized));
            if(GeneralData.connected && GeneralData.socketSender!=null && GeneralData.socketSender.initialized == true){

                GeneralData.socketSender.sendMessage("$heartbeat.check");
                GeneralData.handler.postDelayed(loop, 20000);
            }
        }
    };
}
