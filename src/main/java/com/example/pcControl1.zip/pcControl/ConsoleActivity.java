package com.example.pcControl;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;

import com.example.pcControl.data.GeneralData;
import com.example.pcControl.dialogs.FilesDialog;

public class ConsoleActivity extends AppCompatActivity implements FilesDialog.FilesDialogListener {

    private TextView cmdText;
    private EditText cmdInput;
    private LinearLayout cmdVerticalLayoutScrollView;
    private ScrollView cmdScrollView;
    private Button cmdSendButton;
    private ConstraintLayout layout;
    //private Button rowButtonExtraMcCommand;
    //private Button rowButtonExtraMcMessage;
    private Button rowButtonExtraShutdown;
    private Button rowButtonExtraTaskList;
    //private Button rowButtonExtraSpecialSymbol;
    private Button rowButtonExtraCtrl;
    private Button otherButton;
    private ImageButton scrollDownButton;
    private TextView connectionLostText;
    private Button cmdClearInputButton;
    private Button fodersMenuOkButton;

    private Button rowButtonExtraSpecialSymbols;
    private Button rowButtonExtraSystem;
    private Button rowButtonExtraFiles;

    private ConstraintLayout foldersMenuLayout;

    private Thread printer;
    private int exit = 0;
    private boolean privacy1Done = false;
    //private Handler handler;
    //private Long time;
//    private Long lastTimeKeyboardOpen = -1L;
//    private Long lastTime2Speed = -1L;

    private float consoleClickTypeX1 = -1;
    private float consoleClickTypeY1 = -1;
    private long consoleClickTypeT1 = -1;
    private float consoleClickTypeX2 = -1;
    private float consoleClickTypeY2 = -1;
    private long consoleClickTypeT2 = -1;

    private boolean isRowButtonExtraMcCommandClicked = false;
    private boolean isRowButtonExtraMcMessageClicked = false;
    private boolean isRowButtonExtraCtrlClicked = false;

    private boolean autoscroll = true;
    private boolean keyboardOpen = false;

    private float fadingScrollButtonToAlphaValue = 0f;
    private float fadingScrollButtonToAlphaAmplifier = 0.6f;

    private float fadingClearInputButtonToAlphaValue = 0f;
    private float fadingClearInputToAlphaAmplifier = 0.6f;


    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //requestWindowFeature(Window.FEATURE_NO_TITLE);

        //setTheme(R.style.Theme_Design_Light_NoActionBar);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        Window window = getWindow();
        // clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        // add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

        // finally change the color
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.black));

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_console);

        //closeKeyboard();

        cmdText = findViewById(R.id.cmdOutputTextView);
        cmdInput = findViewById(R.id.cmdInput);
        cmdScrollView = findViewById(R.id.cmdScrollView);
        cmdVerticalLayoutScrollView = findViewById(R.id.cmdScroll_linearLayoutVertical);
        cmdSendButton = findViewById(R.id.cmdSend_btn);
        layout = findViewById(R.id.consoleLayout);
        otherButton = findViewById(R.id.cmdExtraButtonOther);
        connectionLostText = findViewById(R.id.cmd_connectionLost_text);
        rowButtonExtraTaskList = findViewById(R.id.cmdExtraButtonTaskList);
        rowButtonExtraShutdown = findViewById(R.id.cmdExtraButtonShutdown);
        rowButtonExtraSpecialSymbols = findViewById(R.id.cmdExtraButtonSpecialSymbols);
        rowButtonExtraCtrl = findViewById(R.id.cmdExtraButtonCtrl);
        scrollDownButton = findViewById(R.id.cmdScrollDownBtn);
        cmdClearInputButton = findViewById(R.id.cmdClearInput_btn);
        rowButtonExtraSystem = findViewById(R.id.cmdExtraButtonSystem);
        rowButtonExtraFiles = findViewById(R.id.cmdExtraButtonFiles);
        //foldersMenuLayout = findViewById(R.id.foldersmenulayout);
        //fodersMenuOkButton = findViewById(R.id.foldersmenu_okbutton);

        //rowButtonExtraMcCommand = findViewById(R.id.cmdExtraButtonCommand);
        //rowButtonExtraMcMessage = findViewById(R.id.cmdExtraButtonMessage);


//        rowButtonExtraColor.setOnClickListener();

        cmdScrollView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                long CLICK_DURATION = 100;


                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        consoleClickTypeX1 = event.getX();
                        consoleClickTypeY1 = event.getY();
                        consoleClickTypeT1 = System.currentTimeMillis();
                        //System.out.println("return true");
                        return true;
                    case MotionEvent.ACTION_UP:
                        consoleClickTypeX2 = event.getX();
                        consoleClickTypeY2 = event.getY();
                        consoleClickTypeT2 = System.currentTimeMillis();

                        //System.out.println((x2-x1) + " " + (y2-y1));

                        if (Math.abs(consoleClickTypeX2 - consoleClickTypeX1)<=1 && Math.abs(consoleClickTypeY2 - consoleClickTypeY1)<=1 && (consoleClickTypeT2 - consoleClickTypeT1) < CLICK_DURATION) {
                            //Click
                            //System.out.println("Click");
                            doInputStuff();
                        } else if ((consoleClickTypeT2 - consoleClickTypeT1) >= CLICK_DURATION) {
                            //Long click
                            //System.out.println("Long click");
                        } else if (consoleClickTypeX1 > consoleClickTypeX2) {
                           //Left swipe
                            //System.out.println("Left swipe");
                        } else if (consoleClickTypeX2 > consoleClickTypeX1) {
                            //Right swipe
                            //System.out.println("Right swipe");
                        } else if (consoleClickTypeY1 > consoleClickTypeY2) {
                           //Down swipe
                            //System.out.println("Down swipe");
                        } else if (consoleClickTypeY2 > consoleClickTypeY1) {
                            //Up swipe
                            //System.out.println("Up swipe");
                            //System.out.println(cmdScrollView.getScrollY());
                        }


                        return true;
                }

                return false;
            }
        });

        cmdSendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = cmdInput.getText().toString();
                if(!text.trim().equals("")){
                    String consoleText = "> " + text;
                    cmdInput.setText("");

                    if(text.equals("clear")) {
                        GeneralData.lastConsoleOutput = "";
                    }
                    else {

                        if (text.startsWith("send")) {
                            consoleText = "[Sending \"" + text.substring(5) + "\" to the PC]";
                        }

                        if (isRowButtonExtraMcMessageClicked) {
                            GeneralData.socketSender.sendMessage("$mcmessage.normal.text=" + text);
                            consoleText = "Sending to the MC server: " + consoleText;
                        } else if (isRowButtonExtraMcCommandClicked) {
                            GeneralData.socketSender.sendMessage("$mccommand.normal.text=" + text);
                            consoleText = "Executing at the MC server: " + consoleText;
                        } else if (text.startsWith("$")) { //in-app commands
                            GeneralData.socketSender.sendMessage("" + text);
                            if (text.equals("$system.getinfo.tasklist.request")) {
                                consoleText = "> [Request to the system to display the task list]";
                            } else if (text.equals("$system.management.shutdown.usual.request")) {
                                consoleText = "> [Request to the system to SHUTDOWN]";
                            }
                        } else {
                            if (text.split(" ")[0].equals("send")) {
                                GeneralData.socketSender.sendMessage("$rscmessage.normal.text=" + text);
                                //consoleText = "Sending to RSC desktop app: " + consoleText;
                            } else {
                                GeneralData.socketSender.sendMessage("$rsccommand.normal.text=" + text);
                            }
                        }
                        GeneralData.lastConsoleOutput += consoleText + "\n";
                    }
                    //GeneralData.socketSender.sendMessage(text);
                }
            }
        });

        otherButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent startIntent = new Intent(getApplicationContext(), OtherActivity.class);
                startActivity(startIntent);
            }
        });

        scrollDownButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                autoscroll = true;
                fadingScrollButtonToAlphaValue = 0f;
                cmdScrollView.post(scrollDownRunnable);
                //scrollDownButton.setVisibility(View.INVISIBLE);
            }
        });

        /*rowButtonExtraMcCommand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isRowButtonExtraMcCommandClicked = !isRowButtonExtraMcCommandClicked;
                if(isRowButtonExtraMcCommandClicked){
                    rowButtonExtraMcCommand.setTextColor(Color.parseColor("#17eb00"));
                }
                else{
                    rowButtonExtraMcCommand.setTextColor(Color.parseColor("#FFFFFF"));
                }
                //rowButtonExtraMcCommand.setBackgroundColor(Color.parseColor("#5e5e5e"));
            }
        });

        rowButtonExtraMcMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isRowButtonExtraMcMessageClicked = !isRowButtonExtraMcMessageClicked;
                if(isRowButtonExtraMcMessageClicked){
                    rowButtonExtraMcMessage.setTextColor(Color.parseColor("#17eb00"));
                }
                else{
                    rowButtonExtraMcMessage.setTextColor(Color.parseColor("#FFFFFF"));
                }
                //rowButtonExtraMcCommand.setBackgroundColor(Color.parseColor("#5e5e5e"));
            }
        });*/

        rowButtonExtraCtrl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isRowButtonExtraCtrlClicked = !isRowButtonExtraCtrlClicked;
                if(isRowButtonExtraCtrlClicked){

                    //rowButtonExtraCtrl.setBackgroundTintList(contextInstance.getResources().getColorStateList(R.color.your_xml_name));
                    rowButtonExtraCtrl.setTextColor(Color.parseColor("#FF6200EE")); //without theme
                }
                else{
                    rowButtonExtraCtrl.setTextColor(Color.parseColor("#FFFFFF")); //without theme
                }
                //rowButtonExtraMcCommand.setBackgroundColor(Color.parseColor("#5e5e5e"));
            }
        });

        rowButtonExtraTaskList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                String s = "§";
                String s = "$system.getinfo.tasklist.request";
                int index = cmdInput.getSelectionStart();
                Editable editable = cmdInput.getText();
                editable.insert(index, s);
//                System.out.println(keyboardOpen);
//                System.out.println(cmdScrollView.getY());
//                System.out.println("heartBeats:" + GeneralData.heartBeatsNumber);
                //cmdInput.setText(cmdInput.getText().toString()+"§");

            }
        });
//        System.out.println(textView);

        /*rowButtonExtraSpecialSymbol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s = "$";
                int index = cmdInput.getSelectionStart();
                Editable editable = cmdInput.getText();
                editable.insert(index, s);
            }
        });*/

        rowButtonExtraShutdown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                String s = "§";
                    String s = "$system.management.shutdown.usual.request";
                int index = cmdInput.getSelectionStart();
                Editable editable = cmdInput.getText();
                editable.insert(index, s);
//                System.out.println(keyboardOpen);
//                System.out.println(cmdScrollView.getY());
//                System.out.println("heartBeats:" + GeneralData.heartBeatsNumber);
                //cmdInput.setText(cmdInput.getText().toString()+"§");

            }
        });

        cmdClearInputButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Editable editable = cmdInput.getText();
                editable.clear();
                fadingClearInputButtonToAlphaValue = 0f;
            }
        });

        rowButtonExtraSystem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popupMenu = new PopupMenu(ConsoleActivity.this, v);
                popupMenu.getMenuInflater().inflate(R.menu.system_commands_popup, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        switch (menuItem.getItemId()){
                            case R.id.item_tasklist:
                                GeneralData.socketSender.sendMessage("$system.getinfo.tasklist.request");
                                return true;
                            case R.id.item_shutdown_turnoff:
                                GeneralData.socketSender.sendMessage("$system.management.shutdown.usual.request");
                                return true;
                            case R.id.item_shutdown_restart:
                                GeneralData.socketSender.sendMessage("$system.management.shutdown.restart.request");
                                return true;
                            default:
                                return false;
                        }
                    }
                });
                popupMenu.show();
            }
        });

        rowButtonExtraSpecialSymbols.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popupMenu = new PopupMenu(ConsoleActivity.this, v);
                popupMenu.getMenuInflater().inflate(R.menu.special_symbols_popup, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        switch (menuItem.getItemId()){
                            case R.id.item_paragraph:
                                addTextToInput("§");
                                return true;
                            case R.id.item_dollar:
                                addTextToInput("$");
                                return true;
                            default:
                                return false;
                        }
                    }
                });
                popupMenu.show();
            }
        });

        rowButtonExtraFiles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popupMenu = new PopupMenu(ConsoleActivity.this, v);
                popupMenu.getMenuInflater().inflate(R.menu.files_actions_popup, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        switch (menuItem.getItemId()){
                            case R.id.item_tolocation:
                                //GeneralData.socketSender.sendMessage("$system.files.cd");
                                //foldersMenuLayout.setVisibility(View.VISIBLE);
                                openFilesDialog();
                                GeneralData.reloadFoldersFilesList();
                                return true;
                            case R.id.item_allfileslist:
                                GeneralData.socketSender.sendMessage("$system.files.fileslist.request");
                                return true;
                            case R.id.item_folderslist:
                                GeneralData.socketSender.sendMessage("$system.files.folderslist.request");
                                return true;
                            case R.id.item_nonfolderslist:
                                GeneralData.socketSender.sendMessage("$system.files.nonfolderslist.request");
                                return true;
                            case R.id.item_printLocation:
                                GeneralData.lastConsoleOutput += GeneralData.currentFolder + "\n\n";
                                return true;
                            case R.id.item_folderinfo:

                                return true;
                            default:
                                return false;
                        }
                    }
                });
                popupMenu.show();
            }
        });

        //while (true) {
            //((TextView) findViewById(R.id.cmdOutputTextView)).setText(GeneralData.lastConsoleOutput);
        //}

        //Thread printer = new Thread(new Printer(textView));
        //printer.start();

        cmdInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println("cmdInput start" + keyboardOpen);
                keyboardOpen = true;
                System.out.println("cmdInput end" + keyboardOpen);
            }
        });

        startRunnables();
    }

    private void startRunnables(){
        if(GeneralData.handler==null){
            GeneralData.handler = new Handler();
        }
//        if(!privacy1Done) {
//            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
//            StrictMode.setThreadPolicy(policy);
//            privacy1Done = true;
//        }

        GeneralData.handler.postDelayed(loopPrinter, 50);
        GeneralData.handler.postDelayed(loopCleaner, 50);
        GeneralData.handler.postDelayed(liteLoopNoDelay, 0);
    }

    private Runnable liteLoopNoDelay = new Runnable() {
        @Override
        public void run() {
            if(cmdInput.getText().toString().equals("")){
                fadingClearInputButtonToAlphaValue = 0f;
            }
            else{
                fadingClearInputButtonToAlphaValue = 0.8f;
            }

            float lerpedOpacityScrollButton = (scrollDownButton.getAlpha() + fadingScrollButtonToAlphaValue) * fadingScrollButtonToAlphaAmplifier;
            float lerpedOpacityClearButton = (scrollDownButton.getAlpha() + fadingClearInputButtonToAlphaValue) * fadingClearInputToAlphaAmplifier;
            //System.out.println("(" + scrollDownButton.getAlpha() + " + " + fadingScrollButtonToAlphaValue + ") * " + fadingScrollButtonToAlphaAmplifier + " = " + lerpedOpacity);

            scrollDownButton.setAlpha(lerpedOpacityScrollButton);
            cmdClearInputButton.setAlpha(lerpedOpacityClearButton);

            System.out.println(cmdClearInputButton.getAlpha());
            if(cmdClearInputButton.getAlpha()<0.2f){
                cmdClearInputButton.setVisibility(View.GONE);
            }
            else{
                cmdClearInputButton.setVisibility(View.VISIBLE);
            }

            GeneralData.handler.postDelayed(liteLoopNoDelay, 1);
        }
    };

    private Runnable loopCleaner = new Runnable() {
        @Override
        public void run() {
            String current = GeneralData.lastConsoleOutput;
            String[] array = current.split("\n");
            //String[] newArray = new String[GeneralData.maxOutputLines];
            String newString = "";

            if(array.length > GeneralData.maxOutputLines){
                for (int i = (array.length-GeneralData.maxOutputLines); i < array.length; i++){
                    newString += array[i] + "\n";
                }
                GeneralData.lastConsoleOutput = newString;
            }

            System.out.println("text:" + cmdInput.getText() + "| " + cmdInput.getText().toString().equals(""));

            GeneralData.handler.postDelayed(loopCleaner, 1000);
        }
    };

    private Runnable loopPrinter = new Runnable(){
        int i = 0;
        int maxI = 10;
        @Override
        public void run() {
            if (exit == 0) {
                if (i >= maxI) {
                    //System.out.println(autoscroll + ", " + i);
                    if (cmdScrollView.getScrollY() >= (cmdScrollView.getChildAt(0).getHeight() - cmdScrollView.getHeight())) {
                        autoscroll = true;
                        fadingScrollButtonToAlphaValue = 0f;
                        //scrollDownButton.setVisibility(View.INVISIBLE);
                    } else {
                        autoscroll = false;
                        fadingScrollButtonToAlphaValue = 0.5f;
                        //scrollDownButton.setVisibility(View.VISIBLE);
                    }
                }
                String previousText = cmdText.getText().toString();
                cmdText.setText(GeneralData.lastConsoleOutput);
                if (!previousText.equals(GeneralData.lastConsoleOutput) && (autoscroll)) {
                    cmdScrollView.post(scrollDownRunnable);
                    //cmdScrollView.scrollTo(0, 9999999);
                }
                //System.out.println("Changed console text");
                System.out.println("GeneralData.disconnected = " + GeneralData.disconnected + "; !GeneralData.connected = " + !GeneralData.connected);
                if (GeneralData.disconnected || !GeneralData.connected) {
                    connectionLostText.setVisibility(View.VISIBLE);
                } else {
                    connectionLostText.setVisibility(View.INVISIBLE);
                }

                //time = Calendar.getInstance().getTimeInMillis();

                i++;
                if (i > maxI) {
                    i = 0;
                }



                GeneralData.handler.postDelayed(loopPrinter, 10);
            }
        }
    };

    private Runnable scrollDownRunnable = new Runnable() {
        @Override
        public void run() {
            cmdScrollView.fullScroll(ScrollView.FOCUS_DOWN);
        }
    };

    public void doInputStuff(){
        System.out.println("doInputStuff start " + keyboardOpen);
        focusOnInput();
        openKeyboard();

        keyboardOpen = !keyboardOpen;
//        System.out.println(cmdScrollView.getY());
        doKeyboardStuff();
        System.out.println("doInputStuff end " + keyboardOpen);
    }

    public void doKeyboardStuff(){
        if(true) {
            return;
        }
        //System.out.println("doKeyboardStuff start " + keyboardOpen);
        //System.out.println(cmdScrollView.getHeight());
        if(keyboardOpen){
            GeneralData.handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    cmdScrollView.setY(880);

                }
            }, 250);
        }
        else{
            cmdScrollView.setY(0);
        }
        //System.out.println("doKeyboardStuff end " + keyboardOpen);
    }

    public void openKeyboard(){
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
        //keyboardOpen = true;
    }

    public void closeKeyboard(){
        //keyboardOpen = false;
        InputMethodManager imm = (InputMethodManager)getSystemService(
                Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(cmdInput.getWindowToken(), 0);
    }

    public void focusOnInput(){
        cmdInput.requestFocus();
    }

    @Override
    public void onBackPressed() {
        System.out.println("onBackPressed start " + keyboardOpen);
        if(keyboardOpen){
            keyboardOpen = false;
        }
        else{
            exit = 1;
        }
        doKeyboardStuff();
        System.out.println("onBackPressed end " + keyboardOpen);
        super.onBackPressed();
    }

    private void addTextToInput(String text){
        int index = cmdInput.getSelectionStart();
        Editable editable = cmdInput.getText();
        editable.insert(index, text);
    }

    private void openFilesDialog(){
        FilesDialog filesDialog = new FilesDialog();
        filesDialog.show(getSupportFragmentManager(), "Dialog");
    }

    @Override
    public void applyData(String folder, String fullPath) {

        //String s = "asd\\asdsdf\\adfsd/sdfsd";
        //System.out.println(s.replace("\\", "/"));

        fullPath.replace("/", GeneralData.systemSeparator);
        fullPath.replace("\\\\", GeneralData.systemSeparator);

        folder.replace("/", GeneralData.systemSeparator);
        folder.replace("\\\\", GeneralData.systemSeparator);

        if(fullPath.startsWith(GeneralData.currentFolder)) {
            boolean contains = false;
            String lastfolder = folder;
            for (int i = 0; i < GeneralData.foldersList.length; i++) {
                System.out.println("Folder: " + GeneralData.foldersList[i]);
                if (GeneralData.foldersList[i].equals(folder)){
                    contains = true;
                }
            }

            String[] pathParts = fullPath.split(GeneralData.systemSeparator + GeneralData.systemSeparator);

            if(lastfolder.equals("")) {
                lastfolder = pathParts[pathParts.length - 1];
            }

            if(contains){
                GeneralData.currentFolder = fullPath; // += GeneralData.systemSeparator + fullPath;
                GeneralData.socketSender.sendMessage("$system.files.changelocation.request.new=" + GeneralData.currentFolder);
            }
            else{
                GeneralData.lastConsoleOutput += "Folder \"" + lastfolder + "\" doesn't exit!\n\n"; //idk why another one is working but ok fine let it be
            }
            GeneralData.reloadFoldersFilesList();
        }
        else{
            GeneralData.currentFolder = fullPath; // += GeneralData.systemSeparator + fullPath;
            GeneralData.socketSender.sendMessage("$system.files.changelocation.request.new=" + GeneralData.currentFolder);
        }
        //if(folder.)
        //GeneralData.
        /*if(fullPath!=null && !fullPath.equals("")){
            if(folder!=null && !folder.equals("")){
                GeneralData.lastConsoleOutput += "Using full path";
            }
        }
        else if(folder!=null && !folder.equals("")){

        }
        //what if both?
        else{
            GeneralData.lastConsoleOutput += "Enter the folder name OR path, you've done something wrong";
        }*/
    }
}